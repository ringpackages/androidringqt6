rem	Simple Batch file to update Ring and RingQt6 in the Android-Qt6 Version
rem	Author : Mahmoud Fayed <msfclipper@yahoo.com>
rem	The RingQt6 files are generated from the folder : ring/extensions/ringqt6

copy ..\..\..\..\language\src\*.c ..\project\ring\src\
copy ext.c ..\project\ring\src\
copy ..\..\..\..\language\include\*.h ..\project\ring\include\
copy ext.h ..\project\ring\include\
cd ..\..\..\ringqt6\

rem Generate the Android version of the C++ code
set RINGQT_WEBASSEMBLY=
set RINGQT_ANDROID=1
set RINGQT_NOWEBKIT=
set RINGQT_NOBLUETOOTH=1
set RINGQT_NOSVG=
..\..\bin\ring ..\codegen\parsec.ring classes\qt.cf cpp\src\ring_qt.cpp ..\android\ringqt6\update_ring\ring_qt_android.ring
cd events
..\..\..\bin\ring qtevents.ring
cd ..
copy cpp\src\*.cpp ..\android\ringqt6\project\ringqt\src\
copy cpp\include\*.h ..\android\ringqt6\project\ringqt\include\

rem Restore the default version of the C++ code (Full - No Bluetooth)
set RINGQT_WEBASSEMBLY=
set RINGQT_ANDROID=
set RINGQT_NOCORE=
set RINGQT_NOGUI=
set RINGQT_NOWIDGETS=
set RINGQT_NOTESTLIB=
set RINGQT_NOOPENGL=
set RINGQT_NOMULTIMEDIA=
set RINGQT_NOMULTIMEDIAWIDGETS=
set RINGQT_NOPRINTSUPPORT=
set RINGQT_NONETWORK=
set RINGQT_NOSQL=
set RINGQT_NOPOSITIONING=
set RINGQT_NOSERIALPORT=
set RINGQT_NOAXCONTAINER=
set RINGQT_NOQUICKWIDGETS=
set RINGQT_NOQML=
set RINGQT_NOSPEECH=
set RINGQT_NOQT3D=
set RINGQT_NOCHARTS=
set RINGQT_NOGRAPHICSSVG=
set RINGQT_NOSVG=
set RINGQT_NOWEBKIT=1
set RINGQT_NOWEBKITWIDGETS=1
set RINGQT_NOBLUETOOTH=1
set RINGQT_NOWEBENGINEWIDGETS=
..\..\bin\ring ..\codegen\parsec.ring classes\qt.cf cpp\src\ring_qt.cpp ..\android\ringqt6\update_ring\ring_qt_android.ring
cd events
..\..\..\bin\ring qtevents.ring
cd ..
set RINGQT_NOWEBKIT=
set RINGQT_NOWEBKITWIDGETS=
set RINGQT_NOBLUETOOTH=
del ..\android\ringqt6\update_ring\ring_qt_android.ring
cd ..\android\ringqt6\update_ring
