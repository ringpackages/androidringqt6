/* Copyright (c) 2013-2026 Mahmoud Fayed <msfclipper@yahoo.com> */

#ifndef ring_codegen_h
#define ring_codegen_h
/* Intermediate Code */
typedef enum IC_OPERATIONS {
	/* Debug Information */
	ICO_NEWLINE = RING_ZERO,
	ICO_FILENAME,
	ICO_NEWLABEL,
	ICO_SETOPCODE,
	ICO_NOOP,
	/* Program Structure */
	ICO_PACKAGE,
	ICO_IMPORT,
	ICO_NEWCLASS,
	ICO_NEWFUNC,
	ICO_NEWOBJ,
	ICO_PRIVATE,
	/* Custom Global Scope */
	ICO_NEWGLOBALSCOPE,
	ICO_ENDGLOBALSCOPE,
	ICO_SETGLOBALSCOPE,
	/* Using Stack */
	ICO_PUSHC,
	ICO_PUSHNL,
	ICO_PUSHN,
	ICO_PUSH2N,
	ICO_PUSHV,
	ICO_PUSHP,
	ICO_PUSHPV,
	ICO_PUSHPLOCAL,
	ICO_PUSHARG,
	ICO_POP,
	ICO_FREESTACK,
	ICO_DUPLICATE,
	/* Control Structures */
	ICO_JUMP,
	ICO_JUMPZERO,
	ICO_JUMPONE,
	ICO_JUMPFOR,
	ICO_JUMPZERO2,
	ICO_JUMPONE2,
	ICO_PUSHNULLTHENJUMP,
	ICO_PUSHNTHENJUMP,
	/* Advanced Jump */
	ICO_BLOCKFLAG,
	ICO_BYE,
	ICO_EXITMARK,
	ICO_POPEXITMARK,
	ICO_EXIT,
	ICO_INCJUMP,
	ICO_INCPJUMP,
	ICO_TRY,
	ICO_DONE,
	/* Loop/Continue */
	ICO_LOOP,
	ICO_OPTIONALLOOP,
	/* Loop optimization in functions (local scope) */
	ICO_INCLPJUMP,
	/* For-In References */
	ICO_SETREFERENCE,
	ICO_KILLREFERENCE,
	/* For Loop Step */
	ICO_STEPNUMBER,
	ICO_STEPFROMREG,
	ICO_POPSTEP,
	ICO_LOADAFIRST,
	ICO_INCPJUMPSTEP1,
	ICO_INCLPJUMPSTEP1,
	ICO_INCPJUMPFORSTEP1,
	ICO_INCLPJUMPFORSTEP1,
	/* Variables */
	ICO_LOADADDRESS,
	ICO_BEFOREEQUAL,
	ICO_ASSIGNMENTPOINTER,
	ICO_ASSIGNMENT,
	ICO_LOADSUBADDRESS,
	ICO_LOADINDEXADDRESS,
	ICO_LOADAPUSHV,
	ICO_FREELOADASCOPE,
	/* Lists */
	ICO_LISTSTART,
	ICO_LISTITEM,
	ICO_LISTITEMN,
	ICO_LISTITEMC,
	ICO_LISTEND,
	ICO_FREETEMPLISTS,
	ICO_LEN,
	ICO_RANGE,
	/* Arithmetic */
	ICO_SUM,
	ICO_SUB,
	ICO_MUL,
	ICO_DIV,
	ICO_MOD,
	ICO_NEG,
	ICO_INC,
	ICO_INCP,
	ICO_POW,
	ICO_SUMN,
	ICO_SUBN,
	ICO_MULN,
	ICO_DIVN,
	ICO_MODN,
	ICO_POWN,
	/* Increment and Decrement */
	ICO_PLUSPLUS,
	ICO_MINUSMINUS,
	/* Logic */
	ICO_AND,
	ICO_OR,
	ICO_NOT,
	/* Bitwise Operators */
	ICO_BITAND,
	ICO_BITOR,
	ICO_BITNOT,
	ICO_BITXOR,
	ICO_BITSHL,
	ICO_BITSHR,
	/* Comparison operators */
	ICO_EQUAL,
	ICO_LESS,
	ICO_GREATER,
	ICO_NOTEQUAL,
	ICO_LESSEQUAL,
	ICO_GREATEREQUAL,
	/* Functions */
	ICO_LOADFUNC,
	ICO_LOADFUNCP,
	ICO_CALL,
	ICO_RETURN,
	ICO_RETNULL,
	ICO_RETFROMEVAL,
	ICO_RETITEMREF,
	ICO_RETURNN,
	ICO_ANONYMOUS,
	/* Properties/Methods/Braces */
	ICO_LOADMETHOD,
	ICO_SETSCOPE,
	ICO_AFTERCALLMETHOD,
	ICO_AFTERCALLMETHOD2,
	ICO_BRACESTART,
	ICO_BRACEEND,
	ICO_CHECKBRACEMETHOD,
	ICO_LOADMETHODP,
	ICO_LOADBRACEMETHODP,
	ICO_SETPROPERTY
} IC_OPERATIONS;
/* Operations Text (Array) */
static const char *RING_IC_OP[] = {"NewLine",
				   "FileName",
				   "NewLabel",
				   "SetOPCode",
				   "NoOperation",
				   "Package",
				   "Import",
				   "Class",
				   "Func",
				   "New",
				   "Private",
				   "NewGlobalScope",
				   "EndGlobalScope",
				   "SetGlobalScope",
				   "PushC",
				   "PushNL",
				   "PushN",
				   "Push2N",
				   "PushV",
				   "PushP",
				   "PushPV",
				   "PushPLocal",
				   "PushArg",
				   "Pop",
				   "FreeStack",
				   "Dup",
				   "Jump",
				   "JumpZ",
				   "Jump1",
				   "JumpFor",
				   "JumpZero2",
				   "JumpOne2",
				   "PushNullThenJump",
				   "PushNThenJump",
				   "BlockFlag",
				   "Bye",
				   "ExitMark",
				   "PopExitMark",
				   "Exit",
				   "IncJump",
				   "IncPJump",
				   "Try",
				   "Done",
				   "Loop",
				   "OptionalLoop",
				   "IncLPJump",
				   "SetReference",
				   "KillReference",
				   "StepNumber",
				   "StepFromReg",
				   "PopStep",
				   "LoadAFirst",
				   "IncPJumpStep1",
				   "IncLPJumpStep1",
				   "IncPJumpForStep1",
				   "IncLPJumpForStep1",
				   "LoadA",
				   "BeforeEqual",
				   "AssignmentPointer",
				   "Assignment",
				   "LoadSA",
				   "LoadIA",
				   "LoadAPushV",
				   "FreeLoadAScope",
				   "ListStart",
				   "ListItem",
				   "ListItemN",
				   "ListItemC",
				   "ListEnd",
				   "FreeTempLists",
				   "Len",
				   "Range",
				   "Sum",
				   "Sub",
				   "Mul",
				   "Div",
				   "Mod",
				   "Negative",
				   "Inc",
				   "IncP",
				   "Pow",
				   "SumN",
				   "SubN",
				   "MulN",
				   "DivN",
				   "ModN",
				   "PowN",
				   "++",
				   "--",
				   "And",
				   "Or",
				   "Not",
				   "BitAnd",
				   "BitOr",
				   "BitNot",
				   "BitXOr",
				   "BitShiftL",
				   "BitShiftR",
				   "==",
				   "<",
				   ">",
				   "!=",
				   "<=",
				   ">=",
				   "LoadFunc",
				   "LoadFuncP",
				   "Call",
				   "Return",
				   "ReturnNull",
				   "RetFromEval",
				   "RetItemRef",
				   "ReturnN",
				   "Anonymous",
				   "LoadMethod",
				   "SetScope",
				   "AfterCallMethod",
				   "AfterCallMethod2",
				   "BraceStart",
				   "BraceEnd",
				   "CheckBraceMethod",
				   "LoadMethodP",
				   "LoadBraceMethodP",
				   "SetProperty"};
/* Constants */
#define RING_PARSER_ICG_INSTRUCTIONSLISTTYPE List
#define RING_PARSER_ICG_OPERATIONCODE 1
#define RING_PARSER_ICG_PARA1 2
#define RING_PARSER_ICG_PARA2 3
#define RING_PARSER_ICG_PARENTCLASSPOS 4
#define RING_PARSER_ICG_LOADASETTERPOS 3
#define RING_PARSER_ICG_USEASSIGNMENT 1
#define RING_PARSER_ICG_USESETPROPERTY 2
#define RING_PARSER_ICG_NORMALPP 3
#define RING_PARSER_ICG_NORMALMM 4
#define RING_PARSER_ICG_ASSIGNPTRENABLEPOS 2
/* Macro */
#define RING_PARSER_ICG_GOTOLASTOP                                                                                     \
	pParser->pActiveGenCodeList = ring_list_getlist(pParser->pGenCode, ring_list_getsize(pParser->pGenCode))
#define RING_PARSER_ICG_NOOPERATION -1
#define ring_parser_icg_newlabel(pParser)                                                                              \
	(ring_list_getsize(pParser->pGenCode) + 1 + pParser->pRingState->nInstructionsCount)
#define ring_parser_icg_setlastoperation(pParser, nOPCode)                                                             \
	ring_list_setint_gc(pParser->pRingState, pParser->pActiveGenCodeList, RING_PARSER_ICG_OPERATIONCODE, nOPCode)
#define ring_parser_icg_instructionscount(pParser)                                                                     \
	ring_list_getsize(pParser->pGenCode) + pParser->pRingState->nInstructionsCount
#define ring_parser_icg_instructionslistsize(pParser) ring_list_getsize(pParser->pGenCode)
#define ring_parser_icg_getoperationlist(pParser, nIndex) ring_list_getlist(pParser->pGenCode, nIndex)
#define ring_parser_icg_getoperationatpos(pParser, nIndex)                                                             \
	ring_list_getint(ring_parser_icg_getoperationlist(pParser, nIndex), RING_PARSER_ICG_OPERATIONCODE)
#define ring_parser_icg_getoperandint(pParser, nPos) ring_list_getint(pParser->pActiveGenCodeList, nPos)
#define ring_parser_icg_getoperanddouble(pParser, nPos) ring_list_getdouble(pParser->pActiveGenCodeList, nPos)
#define ring_parser_icg_setoperationatpos(pParser, nIndex, nOPCode)                                                    \
	ring_list_setint(ring_parser_icg_getoperationlist(pParser, nIndex), RING_PARSER_ICG_OPERATIONCODE, nOPCode)
/* Generate Intermediate Code */

void ring_parser_icg_newoperation(Parser *pParser, IC_OPERATIONS nOPCode);

void ring_parser_icg_newoperand(Parser *pParser, const char *cStr);

void ring_parser_icg_addtooperand(Parser *pParser, const char *cStr);

void ring_parser_icg_newoperandint(Parser *pParser, int nValue);

void ring_parser_icg_newoperanddouble(Parser *pParser, double nValue);

void ring_parser_icg_newoperandpointer(Parser *pParser, void *pValue);

List *ring_parser_icg_getactiveoperation(Parser *pParser);

void ring_parser_icg_addoperand(Parser *pParser, List *pList, const char *cStr);

void ring_parser_icg_addoperandint(Parser *pParser, List *pList, int nValue);

void ring_parser_icg_addoperandpointer(Parser *pParser, List *pList, void *pValue);

void ring_parser_icg_deletelastoperation(Parser *pParser);

void ring_parser_icg_duplicate(Parser *pParser, unsigned int nStart, unsigned int nEnd);

int ring_parser_icg_newlabel2(Parser *pParser);

void ring_parser_icg_insertoperation(Parser *pParser, int nPos, IC_OPERATIONS nOPCode);

void ring_parser_icg_setopcode(Parser *pParser, List *pList, int nValue);

void ring_parser_icg_deleteoperand(Parser *pParser, int nPos);

const char *ring_parser_icg_getlaststring(Parser *pParser);

void ring_parser_icg_setoperandint(Parser *pParser, List *pList, int nPos, int nValue);

int ring_parser_icg_getlastoperation(Parser *pParser);

int ring_parser_icg_getoperationbeforelastoperation(Parser *pParser);
/* Specific Instructions */

void ring_parser_icg_loadfunction(Parser *pParser, const char *cFunctionName);

void ring_parser_icg_loadaddress(Parser *pParser, const char *cVariableName);

void ring_parser_icg_loadaddresstoloadfunction(Parser *pParser);

void ring_parser_icg_freestack(Parser *pParser);

void ring_parser_icg_newline(Parser *pParser, int nLine);

char *ring_parser_icg_parentclassname(Parser *pParser);

void ring_parser_icg_deleteparentclassname(Parser *pParser);

char *ring_parser_icg_newpackagename(Parser *pParser, List *pPos);

void ring_parser_icg_pushn(Parser *pParser, double nValue);

void ring_parser_icg_beforeequal(Parser *pParser, int nBeforeEqual);

void ring_parser_icg_retnull(Parser *pParser);

void ring_parser_icg_listitem(Parser *pParser);

void ring_parser_icg_gensetglobalscope(Parser *pParser);

void ring_parser_icg_math(Parser *pParser, IC_OPERATIONS nOPCode, IC_OPERATIONS nOPCodeV);

void ring_parser_icg_returnn(Parser *pParser);
/* General Blocks of ByteCode */

void ring_parser_icg_gencallbracemethod(Parser *pParser, const char *cMethod, int lDuplicateStackValue);

void ring_parser_icg_gencall(Parser *pParser, int nCallMethod);

void ring_parser_icg_genfreetemplists(Parser *pParser);

void ring_parser_icg_genppmm(Parser *pParser, int nMode, int nValue);
/* Show the Intermediate Code */

void ring_parser_icg_showoutput(RingState *pRingState);
#endif
